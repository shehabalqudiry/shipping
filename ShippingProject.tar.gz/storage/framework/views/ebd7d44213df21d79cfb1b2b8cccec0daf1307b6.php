<?php $__env->startSection('content'); ?>
<section class="container-fluid mt-0 pt-0">
    <div class="row bg-light">
        <div class="d-flex flex-column flex-shrink-0" style="width: 220px;height:100vh">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
                <span class="fs-4">الحساب</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="<?php echo e(route('front.user.account')); ?>" class="nav-link link-dark <?php echo $__env->yieldContent('active1'); ?>">
                        تفاصيل الحساب
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('front.user.payment_methods')); ?>" class="nav-link link-dark <?php echo $__env->yieldContent('active4'); ?>">
                        وسائل الدفع
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('front.user.address')); ?>" class="nav-link link-dark <?php echo $__env->yieldContent('active6'); ?>">
                        العناوين
                    </a>
                </li>
                <li>
                    <a href="#" class="nav-link link-dark <?php echo $__env->yieldContent('active7'); ?>">
                        الأسعار المحلية
                    </a>
                </li>
            </ul>
        </div>

        <div class="col px-5">
            <?php echo $__env->yieldContent('accountContent'); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shehabalqudiry/Desktop/Projects/ShippingProject/resources/views/pages/user/account/index.blade.php ENDPATH**/ ?>