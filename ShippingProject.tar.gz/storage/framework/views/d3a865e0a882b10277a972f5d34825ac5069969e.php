<?php $__env->startSection('title', 'المستخدمين'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="card-header">
                    <h4>معلومات الحساب</h4>
                </div>
                <div class="card-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 my-2 col-md-4">
                                <label>رقم الحساب</label>
                                <p class="card-text">
                                    <?php echo e(auth()->user()->id); ?>

                                </p>
                            </div>
                            <div class="col-12 my-2 col-md-4">
                                <label>الدولة</label>
                                <p class="card-text">
                                    الاردن
                                </p>
                            </div>
                            <div class="col-12 my-2 col-md-4">
                                <label>العملة</label>
                                <p class="card-text">
                                    JOD
                                </p>
                            </div>
                            <div class="col-12 my-2 col-md-4">
                                <label>نوع الحساب</label>
                                <p class="card-text">
                                    <?php echo e(auth()->user()->type ?? 'شخصي'); ?>

                                </p>
                            </div>
                            <div class="col-12 my-2 col-md-4">
                                <label>رقم الهاتف</label>
                                <p class="card-text">
                                    <?php echo e(auth()->user()->phone); ?>

                                </p>
                            </div>
                            <div class="col-12 my-2 col-md-4">
                                <label>البريد الإلكتروني</label>
                                <p class="card-text">
                                    <?php echo e(auth()->user()->email); ?>

                                </p>
                            </div>
                        </div>
                        <hr />
                        <div class="row">
                            <div class="col-12 my-2 col-md-4">
                                <label>الاسم</label><span class="text-danger">*</span>
                                <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth()->user()->name); ?>"
                                    name="name" />
                            </div>
                            <div class="col-12 my-2 col-md-4">
                                <label>رقم الهاتف</label><span class="text-danger">*</span>
                                <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth()->user()->phone); ?>"
                                    name="phone" />
                            </div>
                            <div class="col-12 my-2 col-md-4">
                                <label>البريد الالكتروني</label><span class="text-danger">*</span>
                                <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth()->user()->email); ?>"
                                    name="email" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-header">
                    <button class="btn btn-primary" type="submit">تحديث</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="row mt-5">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5>الشحنات</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm display" id="basic-1">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>الاسم</th>
                                <th>رقم الهاتف</th>
                                <th>البريد الالكتروني</th>
                                <th>العمليات</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <tr>
                                <td></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <a class="btn btn-primary btn-sm"
                                        href=""><i class="fa fa-edit"></i>
                                        تعديل</a>
                                    <a class="btn btn-info btn-sm" href=""><i
                                            class="fa fa-eye"></i> عرض</a>
                                    <a class="btn btn-danger btn-sm"
                                        href=""><i class="fa fa-trash"></i>
                                        حذف</a>
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shehabalqudiry/Desktop/Projects/ShippingProject/resources/views/admin/users/show.blade.php ENDPATH**/ ?>