<!-- footer start-->
        <footer class="footer">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12 footer-copyright text-center">
                <p class="mb-0">جميع الحقوق محفوظة <?php echo e(date('Y')); ?> © ازرع العراق  تطوير شركة ميتا فور تيك  </p>
              </div>
            </div>
          </div>
        </footer><?php /**PATH /home/shehabalqudiry/Desktop/Projects/ShippingProject/resources/views/admin/layouts/inc/footer.blade.php ENDPATH**/ ?>