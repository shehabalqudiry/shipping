<!-- Google font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@500&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/font-awesome.css">
    <!-- ico-font-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/icofont.css">
    <!-- Themify icon-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/themify.css">
    <!-- Flag icon-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/flag-icon.css">
    <!-- Feather icon-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/feather-icon.css">
    <!-- Plugins css start-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/scrollbar.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/animate.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/chartist.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/date-picker.css">

    <!-- Plugins css start-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/owlcarousel.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/prism.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/whether-icon.css">
    <!-- Plugins css Ends-->
    <!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/vendors/datatables.css">
    <!-- App css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/style.css">
    <link id="color" rel="stylesheet" href="<?php echo e(asset('assets/admin')); ?>/css/color-1.css" media="screen">
    <!-- Responsive css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin')); ?>/css/responsive.css">
<?php /**PATH /home/shehabalqudiry/Desktop/Projects/ShippingProject/resources/views/admin/layouts/inc/styles.blade.php ENDPATH**/ ?>